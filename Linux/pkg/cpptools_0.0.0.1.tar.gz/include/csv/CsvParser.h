#include <iostream>
#include <string>
#include <vector>
#include <cstring>

class CsvParser 
{
public:

    int load(const char* csv_file);

    std::string get(int row, int column);

    std::vector<std::string> getColumn(std::string label);

    std::vector<std::string> getHeaders();

    std::string getLabel(int colNumber);

    std::vector<std::string> getLine(int lineNumber);

    std::vector<std::string> getColumn(int colNumber);

    /// @brief Delete all the loaded data (but not the headers)
    void clear();

    /// @brief hange the header values
    /// Regularize data according to the number of labels in the header
    /// @param newHeaders 
    void setHeaders(std::vector<std::string> newHeaders);

    /// @brief Append a new line to the data
    /// @param newLine 
    void appendLine(std::vector<std::string> newLine);
    

    int save(const char *fileName);

private:

    std::vector<std::vector<std::string>> data;
    std::vector<std::string> headers_names;
};




